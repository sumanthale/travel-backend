import userModel from "./user.js";
import postModal from "./post.js";

export const User = userModel;
export const Post = postModal;
