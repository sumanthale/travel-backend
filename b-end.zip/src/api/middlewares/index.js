export { default as auth } from "./auth/check-auth.js";
