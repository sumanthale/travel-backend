// AUTH
export { default as register } from "./auth/register.js";

export { default as getUser } from "./get-user.js";
// // EDIT
export { default as editUser } from "./edit/edit-user.js";

// // OTHER
export { default as deleteUser } from "./delete-user.js";
